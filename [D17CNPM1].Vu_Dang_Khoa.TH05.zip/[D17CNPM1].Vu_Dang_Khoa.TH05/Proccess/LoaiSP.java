/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Proccess;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import Database.Connect;
/**
 *
 * @author xuuan
 */
public class LoaiSP {
    private Connect cn = new Connect();

    // Truy vấn tất cả dữ liệu trong Table LoaiSP
    public List<LoaiSP> getLoaiSP() throws SQLException {
        List<LoaiSP> list = new ArrayList<>();
        String sql = "SELECT * FROM LoaiSP";
        try (Connection connection = cn.connectSQL();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {
             
            while (resultSet.next()) {
                // Assuming LoaiSP has a constructor that takes parameters
                LoaiSP loaiSP = new LoaiSP(resultSet.getString("Maloai"), resultSet.getString("Tenloai"));
                list.add(loaiSP);
            }
        }
        return list;
    }

    // Truy vấn các dòng dữ liệu trong Table LoaiSP theo Maloai
    public LoaiSP getLoaiSP(String ml) throws SQLException {
        String sql = "SELECT * FROM LoaiSP WHERE Maloai=?";
        try (Connection connection = cn.connectSQL();
             PreparedStatement statement = connection.prepareStatement(sql)) {
             
            statement.setString(1, ml);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                return new LoaiSP(resultSet.getString("Maloai"), resultSet.getString("Tenloai"));
            }
        }
        return null; // Return null if no record found
    }

    // Thêm 1 dòng dữ liệu vào table LoaiSP
    public boolean insertData(LoaiSP obj) throws SQLException {
        String sql = "INSERT INTO LoaiSP (Maloai, Tenloai) VALUES (?, ?)";
        try (Connection connection = cn.connectSQL();
             PreparedStatement statement = connection.prepareStatement(sql)) {
             
            statement.setString(1, obj.getMaloai());
            statement.setString(2, obj.getTenloai());
            return statement.executeUpdate() > 0; // Return true if insert is successful
        }
    }

    // Điều chỉnh 1 dòng dữ liệu vào table LoaiSP
    public boolean editData(LoaiSP obj) throws SQLException {
        String sql = "UPDATE LoaiSP SET Tenloai=? WHERE Maloai=?";
        try (Connection connection = cn.connectSQL();
             PreparedStatement statement = connection.prepareStatement(sql)) {
             
            statement.setString(1, obj.getTenloai());
            statement.setString(2, obj.getMaloai());
            return statement.executeUpdate() > 0; // Return true if update is successful
        }
    }

    // Xóa 1 dòng dữ liệu vào table LoaiSP
    public boolean deleteData(String ml) throws SQLException {
        String sql = "DELETE FROM LoaiSP WHERE Maloai=?";
        try (Connection connection = cn.connectSQL();
             PreparedStatement statement = connection.prepareStatement(sql)) {
             
            statement.setString(1, ml);
            return statement.executeUpdate() > 0; // Return true if delete is successful
        }
    }

    // Assuming you have these getter methods in your LoaiSP class
    public String getMaloai() {
        return Maloai;
    }

    public String getTenloai() {
        return Tenloai;
    }

    // Constructor for LoaiSP
    public LoaiSP() {
        this.Maloai = "";
        this.Tenloai = "";
    }
    public LoaiSP(String Maloai, String Tenloai) {
        this.Maloai = Maloai;
        this.Tenloai = Tenloai;
    }
    
  
    private String Maloai;
    private String Tenloai;
}
